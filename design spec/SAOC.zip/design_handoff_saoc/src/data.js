// South African Orchid Council — placeholder data.
// Events use the 2025 society shows mentioned in brief + realistic inventions.

window.SAOC_DATA = {
  societies: [
    { name: "Cape Orchid Society", region: "Western Cape", province: "WC", founded: 1947, meet: "2nd Tue, 19h30", venue: "Kirstenbosch Hall, Cape Town", members: 220 },
    { name: "Natal Orchid Society", region: "KwaZulu-Natal", province: "KZN", founded: 1954, meet: "1st Wed, 19h00", venue: "Durban Botanic Gardens", members: 310 },
    { name: "Transvaal Orchid Society", region: "Gauteng", province: "GP", founded: 1959, meet: "3rd Thu, 19h00", venue: "Walter Sisulu NBG, Roodepoort", members: 280 },
    { name: "Northern Transvaal Orchid Society", region: "Tshwane", province: "GP", founded: 1962, meet: "Last Mon, 19h30", venue: "Pretoria NBG", members: 190 },
    { name: "East Rand Orchid Society", region: "Ekurhuleni", province: "GP", founded: 1974, meet: "2nd Sat, 14h00", venue: "Benoni Country Club", members: 95 },
    { name: "West Rand Orchid Society", region: "Krugersdorp", province: "GP", founded: 1978, meet: "3rd Wed, 19h30", venue: "Walter Sisulu NBG", members: 72 },
    { name: "Lowveld Orchid Society", region: "Mbombela", province: "MP", founded: 1981, meet: "1st Sat, 14h00", venue: "Lowveld NBG, Mbombela", members: 110 },
    { name: "Highveld Orchid Society", region: "Witbank", province: "MP", founded: 1985, meet: "2nd Sun, 14h00", venue: "Witbank Civic Centre", members: 48 },
    { name: "Free State Orchid Society", region: "Bloemfontein", province: "FS", founded: 1970, meet: "Last Sat, 14h30", venue: "Free State NBG", members: 65 },
    { name: "Border Orchid Society", region: "East London", province: "EC", founded: 1976, meet: "3rd Tue, 19h00", venue: "Amathole Museum, King William's Town", members: 54 },
    { name: "Eastern Province Orchid Society", region: "Gqeberha", province: "EC", founded: 1972, meet: "1st Thu, 19h00", venue: "Nelson Mandela Bay Botanical Gardens", members: 88 },
    { name: "Garden Route Orchid Society", region: "George", province: "WC", founded: 1989, meet: "2nd Fri, 18h30", venue: "Garden Route Botanical Garden", members: 76 },
    { name: "Overberg Orchid Society", region: "Hermanus", province: "WC", founded: 1994, meet: "3rd Sat, 14h00", venue: "Hermanus Botanical Society Hall", members: 41 },
    { name: "Winelands Orchid Society", region: "Stellenbosch", province: "WC", founded: 1998, meet: "Last Wed, 19h00", venue: "Stellenbosch University Botanical Garden", members: 62 },
    { name: "Midlands Orchid Society", region: "Pietermaritzburg", province: "KZN", founded: 1983, meet: "2nd Mon, 19h00", venue: "Royal Agricultural Society Hall", members: 84 },
    { name: "North Coast Orchid Society", region: "Ballito", province: "KZN", founded: 1991, meet: "1st Sun, 14h00", venue: "Umhlanga Library", members: 58 },
    { name: "Kalahari Orchid Society", region: "Kimberley", province: "NC", founded: 1988, meet: "Last Thu, 18h30", venue: "McGregor Museum, Kimberley", members: 32 },
    { name: "Limpopo Orchid Society", region: "Polokwane", province: "LP", founded: 1996, meet: "3rd Sat, 10h00", venue: "Polokwane Game Reserve Hall", members: 37 },
    { name: "North West Orchid Society", region: "Potchefstroom", province: "NW", founded: 1992, meet: "2nd Wed, 19h00", venue: "NWU Botanical Garden", members: 44 },
    { name: "Vaal Triangle Orchid Society", region: "Vanderbijlpark", province: "GP", founded: 1986, meet: "Last Tue, 19h00", venue: "Vaal University of Technology Hall", members: 51 },
    { name: "South Cape Orchid Society", region: "Mossel Bay", province: "WC", founded: 2001, meet: "1st Wed, 18h00", venue: "Mossel Bay Library", members: 36 },
  ],

  provinces: [
    { code: "ALL", name: "All provinces" },
    { code: "WC", name: "Western Cape" },
    { code: "EC", name: "Eastern Cape" },
    { code: "NC", name: "Northern Cape" },
    { code: "FS", name: "Free State" },
    { code: "KZN", name: "KwaZulu-Natal" },
    { code: "GP", name: "Gauteng" },
    { code: "MP", name: "Mpumalanga" },
    { code: "LP", name: "Limpopo" },
    { code: "NW", name: "North West" },
  ],

  // 2025 society shows + realistic inventions stretching into 2026
  events: [
    { id: 1, date: "2025-03-15", endDate: "2025-03-16", title: "Cape Orchid Society Autumn Show", host: "Cape Orchid Society", venue: "Kirstenbosch Hall, Cape Town", kind: "Show", province: "WC" },
    { id: 2, date: "2025-04-05", endDate: "2025-04-06", title: "Transvaal Autumn Orchid Show", host: "Transvaal Orchid Society", venue: "Walter Sisulu NBG, Roodepoort", kind: "Show", province: "GP" },
    { id: 3, date: "2025-05-10", title: "Judging Workshop — Paphiopedilum", host: "SAOC Judging", venue: "Pretoria NBG", kind: "Workshop", province: "GP" },
    { id: 4, date: "2025-05-24", endDate: "2025-05-25", title: "Natal Winter Orchid Show", host: "Natal Orchid Society", venue: "Durban Botanic Gardens", kind: "Show", province: "KZN" },
    { id: 5, date: "2025-06-14", endDate: "2025-06-15", title: "Garden Route Winter Show", host: "Garden Route Orchid Society", venue: "George Botanical Garden", kind: "Show", province: "WC" },
    { id: 6, date: "2025-07-12", title: "SAOC Council AGM 2025", host: "SAOC", venue: "Bloemfontein Civic Centre", kind: "Council", province: "FS" },
    { id: 7, date: "2025-08-02", endDate: "2025-08-03", title: "Eastern Province Spring Show", host: "EP Orchid Society", venue: "NMBay Botanical Gardens", kind: "Show", province: "EC" },
    { id: 8, date: "2025-08-23", endDate: "2025-08-24", title: "Lowveld Spring Orchid Show", host: "Lowveld Orchid Society", venue: "Lowveld NBG, Mbombela", kind: "Show", province: "MP" },
    { id: 9, date: "2025-09-06", endDate: "2025-09-07", title: "Northern Transvaal Spring Show", host: "N. Transvaal Orchid Society", venue: "Pretoria NBG", kind: "Show", province: "GP" },
    { id: 10, date: "2025-09-20", endDate: "2025-09-21", title: "Cape Spring Orchid Show", host: "Cape Orchid Society", venue: "Kirstenbosch Hall", kind: "Show", province: "WC" },
    { id: 11, date: "2025-10-11", endDate: "2025-10-12", title: "Midlands Orchid Show", host: "Midlands Orchid Society", venue: "Royal Agricultural Society Hall, PMB", kind: "Show", province: "KZN" },
    { id: 12, date: "2025-10-25", title: "Hybridisation Symposium", host: "SAOC", venue: "Stellenbosch University", kind: "Workshop", province: "WC" },
    { id: 13, date: "2025-11-08", endDate: "2025-11-09", title: "East Rand Cymbidium Show", host: "East Rand Orchid Society", venue: "Benoni Country Club", kind: "Show", province: "GP" },
    { id: 14, date: "2025-11-22", title: "Yearbook Launch — Orchids South Africa 2025", host: "SAOC", venue: "Online + Pretoria NBG", kind: "Launch", province: "GP" },
    { id: 15, date: "2026-02-14", endDate: "2026-02-15", title: "Summer Species Show", host: "Winelands Orchid Society", venue: "Stellenbosch University BG", kind: "Show", province: "WC" },
    { id: 16, date: "2026-03-07", title: "Judging Accreditation Exam — Round 1", host: "SAOC Judging", venue: "Regional Centres", kind: "Council", province: "GP" },
  ],

  // 3-year cycle. Last show 2024 (18th). Next estimated 2027 (19th).
  shows: [
    { edition: 19, year: 2027, month: "September", host: "Western Cape", venue: "Cape Town International Convention Centre", status: "upcoming", days: 4 },
    { edition: 18, year: 2024, month: "September", host: "KwaZulu-Natal", venue: "Durban ICC", status: "past", days: 4, entries: 1240, visitors: 8600, trophies: 37 },
    { edition: 17, year: 2021, month: "October", host: "Gauteng", venue: "Walter Sisulu NBG", status: "past", days: 3, entries: 980, visitors: 5200, trophies: 32, note: "Reduced format — pandemic protocols" },
    { edition: 16, year: 2018, month: "September", host: "Western Cape", venue: "Cape Town City Hall", status: "past", days: 4, entries: 1150, visitors: 7800, trophies: 34 },
    { edition: 15, year: 2015, month: "September", host: "Eastern Cape", venue: "NMBay Boardwalk", status: "past", days: 4, entries: 1020, visitors: 6400, trophies: 31 },
    { edition: 14, year: 2012, month: "October", host: "Free State", venue: "Bloemfontein Showgrounds", status: "past", days: 4, entries: 890, visitors: 5100, trophies: 29 },
  ],

  // Target date for countdown — first day of September 2027.
  nextShowDate: "2027-09-18T09:00:00+02:00",

  // Hero photos — real orchid photography. Rotation starts with yellow for differentiation from the sage palette.
  heroImages: [
    { url: "assets/orchid-yellow.jpg", credit: "Oncidium ‘Sweet Sugar’ — member bench" },
    { url: "assets/orchid-violet.jpg", credit: "Phalaenopsis, dramatic light" },
    { url: "assets/orchid-pink.jpg", credit: "Phalaenopsis spray, Natal chapter" },
    { url: "assets/orchid-dark.jpg", credit: "Harlequin Phalaenopsis, evening" },
  ],

  // Ancillary imagery — 5 real photos, distributed for variety.
  images: {
    greenhouse: "assets/orchid-pink.jpg",
    judging: "assets/orchid-dark.jpg",
    bench: "assets/orchid-yellow.jpg",
    community: "assets/orchid-violet.jpg",
    disa: "assets/orchid-purple.jpg",
    paph: "assets/orchid-yellow.jpg",
    cymbidium: "assets/orchid-pink.jpg",
    yearbook: "assets/orchid-purple.jpg",
    past18: "assets/orchid-yellow.jpg",
    past17: "assets/orchid-violet.jpg",
    past16: "assets/orchid-pink.jpg",
    past15: "assets/orchid-dark.jpg",
  },

  board: [
    { name: "Dr. Annelie van der Merwe", role: "President", society: "Cape Orchid Society", tenure: "2023–" },
    { name: "Sipho Mthembu", role: "Vice-President", society: "Natal Orchid Society", tenure: "2023–" },
    { name: "Margaret Oosthuizen", role: "Secretary", society: "Transvaal Orchid Society", tenure: "2021–" },
    { name: "David Naidoo", role: "Treasurer", society: "N. Transvaal Orchid Society", tenure: "2022–" },
    { name: "Prof. Johan Botha", role: "Chair of Judging", society: "Cape Orchid Society", tenure: "2020–" },
    { name: "Lindiwe Khumalo", role: "Editor, Orchids South Africa", society: "Midlands Orchid Society", tenure: "2024–" },
  ],

  partners: [
    "Wild Orchids of Southern Africa",
    "South African National Biodiversity Institute",
    "Kirstenbosch NBG",
    "American Orchid Society",
    "Royal Horticultural Society",
    "World Orchid Conference",
  ],

  showClasses: [
    { group: "Group 1", name: "Cattleya Alliance", desc: "Cattleya, Laelia, Brassavola, Rhyncholaelia and intergeneric hybrids.", icon: "C" },
    { group: "Group 2", name: "Cymbidium", desc: "Standard, miniature, pendulous and species Cymbidium.", icon: "Cy" },
    { group: "Group 3", name: "Dendrobium", desc: "Den-Phal, hard-cane, soft-cane, nobile type and species.", icon: "D" },
    { group: "Group 4", name: "Paphiopedilum & Phragmipedium", desc: "Slipper orchids — species and hybrids.", icon: "P" },
    { group: "Group 5", name: "Phalaenopsis", desc: "Standard, novelty, multifloral and species Phalaenopsis.", icon: "Ph" },
    { group: "Group 6", name: "Oncidium Alliance", desc: "Oncidium, Miltoniopsis, Odontoglossum and intergenerics.", icon: "O" },
    { group: "Group 7", name: "Vandaceous", desc: "Vanda, Ascocenda, Aerides and related genera.", icon: "V" },
    { group: "Group 8", name: "Species", desc: "All botanical species, including indigenous SA orchids (in cultivation).", icon: "S" },
    { group: "Group 9", name: "Miniatures", desc: "Plants with flowers under 4cm at widest point.", icon: "m" },
    { group: "Group 10", name: "Novice", desc: "Growers who have not won a first prize at SAOC level.", icon: "N" },
  ],

  awards: [
    { code: "AM/SAOC", name: "Award of Merit", threshold: "80–89 pts", desc: "Recognises a plant of superior quality — exceptional form, colour, size, and cultural condition." },
    { code: "FCC/SAOC", name: "First Class Certificate", threshold: "90+ pts", desc: "The highest flower-quality award — reserved for plants of truly outstanding merit." },
    { code: "HCC/SAOC", name: "Highly Commended Certificate", threshold: "75–79 pts", desc: "A plant worthy of recognition, a step below Award of Merit." },
    { code: "CCM/SAOC", name: "Certificate of Cultural Merit", threshold: "80+ pts", desc: "Awarded to the grower for exceptional cultivation — specimen plant quality." },
    { code: "CBR/SAOC", name: "Certificate of Botanical Recognition", threshold: "—", desc: "For the first exhibition of a rare or unusual species." },
    { code: "JC/SAOC", name: "Judges' Commendation", threshold: "—", desc: "For a distinctive characteristic not covered by standard criteria." },
  ],
};
